public class Gorilla extends Mammal{ //use extend to inherit from Mammal class
    //add 'super(method)' for to constructor you want to use from parent class
    public Gorilla(int energyLevel) {
        super(energyLevel);
    }

    public void throwSomething() {
        this.energyLevel -= 5;
        System.out.println("Gorilla has thrown something, take cover!");
    }

    public void eatBananas() {
        this.energyLevel += 10;
        System.out.println("Bananas are yummy");
    }

    public void climb() {
        this.energyLevel -= 10;
        System.out.println("Be careful up there!");
    }
}