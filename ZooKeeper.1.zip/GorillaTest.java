public class GorillaTest {
    public static void main(String[] args) {
        //instantiate a gorilla
        Gorilla chimp = new Gorilla(100); //*must include argument to fulfill inheritance from "energyLevel" from Mammall class

        chimp.throwSomething(); // should print method's return statement
        chimp.eatBananas(); //"^"
        chimp.climb(); //"^"
    }
}